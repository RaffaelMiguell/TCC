<?php

require_once('validacoes_cadastro/validacoes.php');
//para efetuar o login, restringir  antes o tipo de digito
//evitando a inserção de qualquer dado



?>